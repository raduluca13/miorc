const AudioContext = window.AudioContext || window.webkitAudioContext;
const audioContext = new AudioContext();

var audios = document.querySelectorAll('audio');
audios.forEach(element => {
    try {
        const track = audioContext.createMediaElementSource(element)
        track.connect(audioContext.destination)
    }
    catch (error) {
        console.log(error)
    }
});

function addPartiture(partiture){
    let totalDuration = 18 // partiture.duration
    let midiNotes = [25,26,27,27,39,25,40,41,39] // partiture.notes
    let trackNotes = midiNotes.map((node)=>midiDict[`${node}`])
    let trackFrequncies = trackNotes.map((node)=>noteValues[node])
    let singleDuration = totalDuration/trackFrequncies.length
    
    let osc = audioContext.createOscillator()
    osc.type = "sine"
    
    let gain = audioContext.createGain()
    osc.frequency.value = trackFrequncies[0]
    osc.connect(gain)
    gain.connect(audioContext.destination)
    osc.start(0)
    trackFrequncies.forEach((freq)=>{
        osc.frequency.setValueAtTime(freq, audioContext.currentTime + singleDuration)
    })
    osc.stop(0)
}





// let newmid = MidiFile('../MIDI_sample.mid')
// console.log("noimen", newmid)

// async function getBufferedFile(audioContext, filepath) {
//     const response = await fetch(filepath);
//     const arrayBuffer = await response.arrayBuffer();
//     const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
//     return audioBuffer;
// }

// async function setupSample() {
//     const filePath = ['../sorry.wav', '../peace.mp3', '../MIDI_sample.mid']; // ccan take an array
//     const sample = await getBufferedFile(audioContext, filePath);
//     return sample;
// }

// setupSample()
//     .then((sample) => {
//         console.log("loaded")
//         console.log(sample)
//         // sample is our buffered file
//         // ...
//     });

// function playSample(audioContext, audioBuffer) {
//     const sampleSource = audioContext.createBufferSource();
//     sampleSource.buffer = audioBuffer;
//     // sampleSource.playbackRate.setValueAtTime(playbackRate, audioCtx.currentTime);
//     // let tempo = 60.0;
//     // let lookahead = 25.0; // How frequently to call scheduling function (in milliseconds)
//     // let scheduleAheadTime = 0.1; // How far ahead to schedule audio (sec)
//     sampleSource.connect(audioContext.destination)
//     sampleSource.start();
//     return sampleSource;
// }

let main = document.getElementById("main");

main.addEventListener("click", function (e) {
    // if (audioContext.state === 'suspended') {
    //     audioContext.resume();
    //     console.log("audiocontext resumed")
    // }
    switch (e.target.id) {
        case "instrument_container1":
            let instr1 = document.getElementById("aud1")
            if (instr1.paused) instr1.play() // instr1.addEventListener("addtrack", () => console.log("added"))
            else instr1.pause()
            break

        case "instrument_container2":
            let instr2 = document.getElementById("aud2")
            if(instr2.paused) instr2.play()
            else instr2.pause()
            break

        case "play-all-btn":
            audios.forEach(el => {
                if(el.paused) el.play()
                else el.pause()                
            })
            break;
        
        case "stop-all-btn":

        case "addInstrumentDiv":
            
        default:
            break
    }



});

