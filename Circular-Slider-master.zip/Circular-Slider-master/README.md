# Circular-Slider
Circular slider in pure JavaScript

![circular-slider](https://user-images.githubusercontent.com/27735579/39672875-cc3db2d0-5132-11e8-8d47-7c2b44e6002a.png)
